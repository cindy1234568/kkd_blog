# xblog
django blog. bootstrap, markdown

https://shenxgan.github.io/django/

https://shenxgan.gitbooks.io/django/content/
